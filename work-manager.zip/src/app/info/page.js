"use client";
export default function Info() {
  console.log("this is component");

  return (
    <div>
      <h1>This is info component</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, vero.
      </p>
      <button className="px-3 py-2 rounded bg-blue-600">Click here</button>
    </div>
  );
}
