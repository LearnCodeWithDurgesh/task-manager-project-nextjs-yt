import React from "react";
import Signup from "./Signup";

export const metadata = {
  title: "Signup : Work Manager",
};

const SignUpPage = () => {
  return <Signup />;
};

export default SignUpPage;
