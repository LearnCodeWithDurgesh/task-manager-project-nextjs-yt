export default function UserProfile() {
  return <h1>This is normal user proflie</h1>;
}
