export default function Profile() {
  return (
    <div>
      <h1>This is profile route</h1>
    </div>
  );
}
