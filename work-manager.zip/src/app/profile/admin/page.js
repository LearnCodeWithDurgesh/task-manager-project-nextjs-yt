export default function AdminProfile() {
  return <h1>This is admin user proflie</h1>;
}
