import React from "react";
import AddTask from "./AddTask";
export const metadata = {
  title: "Add Task : Work Manager",
};
const AddTaskPage = () => {
  return <AddTask />;
};

export default AddTaskPage;
