import React from "react";
import ShowTasks from "./ShowTasks";
export const metadata = {
  title: "All Tasks : Work Manager",
};
const ShowTasksPage = () => {
  return <ShowTasks />;
};

export default ShowTasksPage;
