"use client";

export default function pageError({ error, reset }) {
  return (
    <div>
      <h1>Error is coming in about route</h1>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestiae
        temporibus explicabo, assumenda a impedit sunt fuga doloremque velit
        animi. Impedit aliquid dolorem nulla harum ex enim voluptates. Quos,
        adipisci. Facilis consectetur tenetur quibusdam magni sint sed eaque
        mollitia inventore veritatis reiciendis dolore unde, magnam enim
        voluptas corporis fuga iusto perferendis!
      </p>
    </div>
  );
}
