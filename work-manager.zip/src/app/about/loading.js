export default function Loading() {
  return (
    <div>
      <p>Loading...</p>
    </div>
  );
}
